import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link, NavLink as RouterNavLink } from 'react-router-dom';

const NavLink = ({ to, children }) => (
  <RouterNavLink
    to={to}
    className={({ isActive }) =>
      `text-foreground hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium ${isActive ? 'text-primary font-semibold' : ''}`
    }
  >
    {({ isActive }) => (
      <motion.span
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {children}
      </motion.span>
    )}
  </RouterNavLink>
);

const Header = () => {
  const logoUrl = "https://storage.googleapis.com/hostinger-horizons-assets-prod/602dd964-0f57-4bc6-be2b-94708998e4a2/180bafe4ceac739ddb00d50f2cf54d6a.png";

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-20">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <Link to="/" className="flex items-center space-x-2">
            <img src={logoUrl} alt="WDC Logo" className="h-12 w-12 object-contain" />
            <span className="font-bold text-xl gradient-text">WDC</span>
          </Link>
        </motion.div>
        <nav className="hidden md:flex space-x-1 lg:space-x-2">
          <NavLink to="/">Home</NavLink>
          <NavLink to="/about">About Us</NavLink>
          <NavLink to="/services">Services</NavLink>
          <NavLink to="/portfolio">Portfolio</NavLink>
          <NavLink to="/blog">Blog</NavLink>
          <NavLink to="/contact">Contact</NavLink>
        </nav>
        <div className="md:hidden">
          {/* Mobile menu button can be added here */}
        </div>
        <Link to="/contact">
          <Button variant="outline" className="hidden md:inline-flex border-primary text-primary hover:bg-primary hover:text-primary-foreground">
            Get in Touch
          </Button>
        </Link>
      </div>
    </motion.header>
  );
};

export default Header;