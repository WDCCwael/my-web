import React from 'react';
import HeroSection from '@/components/HeroSection';
import ServicesSection from '@/components/ServicesSection';
import PortfolioPreviewSection from '@/components/PortfolioPreviewSection';
import ContactSection from '@/components/ContactSection';
import { motion } from 'framer-motion';

const HomePage = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <HeroSection />
      <ServicesSection />
      <PortfolioPreviewSection />
      <ContactSection />
    </motion.div>
  );
};

export default HomePage;