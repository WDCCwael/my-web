import React from 'react';
import { motion } from 'framer-motion';
import { Users, Target, Lightbulb } from 'lucide-react';

const AboutPage = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24"
    >
      <div className="text-center mb-12 md:mb-16">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight mb-4">
          About <span className="gradient-text">WDC</span>
        </h1>
        <p className="max-w-2xl mx-auto text-lg text-muted-foreground">
          Discover the story, mission, and values that drive our creative & development powerhouse.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <h2 className="text-3xl font-bold mb-6 gradient-text">Our Journey</h2>
          <p className="text-muted-foreground mb-4 text-lg leading-relaxed">
            WDC (World Development Creativity Company) was founded with a singular vision: to bridge the gap between cutting-edge development and groundbreaking creativity. We believe that the most impactful digital solutions are born at the intersection of technology and art.
          </p>
          <p className="text-muted-foreground mb-4 text-lg leading-relaxed">
            Over the years, we've partnered with businesses of all sizes, from ambitious startups to established enterprises, helping them navigate the complexities of the digital landscape and achieve their strategic goals. Our passion for innovation and commitment to excellence are the cornerstones of our success.
          </p>
        </div>
        <div className="flex justify-center">
          <img  class="rounded-xl shadow-2xl w-full max-w-md object-cover h-80" alt="WDC team collaborating in a modern office" src="https://images.unsplash.com/photo-1677506048148-0c914dd8197b" />
        </div>
      </div>

      <div className="mb-16">
        <h2 className="text-3xl font-bold text-center mb-10 gradient-text">Our Core Values</h2>
        <div className="grid sm:grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div 
            className="glassmorphism-card p-8 rounded-lg text-center"
            whileHover={{ y: -5, boxShadow: "0px 10px 20px rgba(var(--primary-rgb), 0.2)"}}
          >
            <Lightbulb size={48} className="mx-auto mb-4 text-primary" />
            <h3 className="text-2xl font-semibold mb-3 text-foreground">Innovation</h3>
            <p className="text-muted-foreground">We constantly explore new technologies and creative approaches to deliver forward-thinking solutions.</p>
          </motion.div>
          <motion.div 
            className="glassmorphism-card p-8 rounded-lg text-center"
            whileHover={{ y: -5, boxShadow: "0px 10px 20px rgba(var(--secondary-rgb), 0.2)"}}
          >
            <Users size={48} className="mx-auto mb-4 text-secondary" />
            <h3 className="text-2xl font-semibold mb-3 text-foreground">Collaboration</h3>
            <p className="text-muted-foreground">We work closely with our clients, fostering partnerships built on trust and mutual success.</p>
          </motion.div>
          <motion.div 
            className="glassmorphism-card p-8 rounded-lg text-center"
            whileHover={{ y: -5, boxShadow: "0px 10px 20px rgba(var(--accent-rgb), 0.2)"}}
          >
            <Target size={48} className="mx-auto mb-4 text-accent" />
            <h3 className="text-2xl font-semibold mb-3 text-foreground">Results-Driven</h3>
            <p className="text-muted-foreground">Our focus is on delivering measurable outcomes that contribute to our clients' growth and objectives.</p>
          </motion.div>
        </div>
      </div>
      
      <div>
          <h2 className="text-3xl font-bold mb-6 gradient-text">Meet Our Team (Placeholder)</h2>
          <p className="text-muted-foreground mb-4 text-lg leading-relaxed">
            Our team is a diverse group of passionate strategists, designers, developers, and marketers, united by a shared love for creativity and problem-solving. We are currently working on showcasing our amazing team members here!
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            <div className="flex flex-col items-center p-4 glassmorphism-card rounded-lg">
              <img  class="w-24 h-24 rounded-full mb-2 object-cover" alt="Team Member 1" src="https://images.unsplash.com/photo-1684262855344-b9da453a7934" />
              <h4 className="font-semibold text-foreground">Team Member 1</h4>
              <p className="text-xs text-muted-foreground">Role/Title</p>
            </div>
            <div className="flex flex-col items-center p-4 glassmorphism-card rounded-lg">
              <img  class="w-24 h-24 rounded-full mb-2 object-cover" alt="Team Member 2" src="https://images.unsplash.com/photo-1493882552576-fce827c6161e" />
              <h4 className="font-semibold text-foreground">Team Member 2</h4>
              <p className="text-xs text-muted-foreground">Role/Title</p>
            </div>
            <div className="flex flex-col items-center p-4 glassmorphism-card rounded-lg">
              <img  class="w-24 h-24 rounded-full mb-2 object-cover" alt="Team Member 3" src="https://images.unsplash.com/photo-1690191886622-fd8d6cda73bd" />
              <h4 className="font-semibold text-foreground">Team Member 3</h4>
              <p className="text-xs text-muted-foreground">Role/Title</p>
            </div>
            <div className="flex flex-col items-center p-4 glassmorphism-card rounded-lg">
              <img  class="w-24 h-24 rounded-full mb-2 object-cover" alt="Team Member 4" src="https://images.unsplash.com/photo-1573166364366-3f4f8b1857ea" />
              <h4 className="font-semibold text-foreground">Team Member 4</h4>
              <p className="text-xs text-muted-foreground">Role/Title</p>
            </div>
          </div>
      </div>

    </motion.div>
  );
};

export default AboutPage;